/*	This program demonstrates binary expressions using floating-point arithmetic.
	written by :
	Date :
*/
#include<stdio.h>
main()
{
/* Local Definitions */
float a = 14.0;
float b = 5.0;

/*Statements*/

printf("%f + %f = %f\n", a ,b, a + b);
printf("%f - %f = %f\n", a ,b, a - b);
printf("%f * %f = %f\n", a ,b, a * b);
printf("%f / %f = %f\n", a ,b, a / b);
}