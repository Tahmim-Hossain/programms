/*	This program demonstrates use of putchar function.
	written by :
	Date :
*/
#include<stdio.h>
main()
{
	char c ='A';
	putchar(c);
}