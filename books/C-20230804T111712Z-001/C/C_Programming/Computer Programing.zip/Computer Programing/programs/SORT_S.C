/* The program sorts the array in the ascending order using selection sort */
#include <stdio.h>
void main()
{
	int i, j, k, data , count, exchange;
	int x[5] = {58, 42, 12, 38, 15};

	for (i = 0;  i<count - 1; i++)
	{
		exchange = 0;
		k = i;
		data = x[i];
		for (j = i+1; j < 5; j++)
			{
				if (x[j]<data)
					{
						k = j;
						data = x [j];
						exchange = 1;
					}
			}
			if (exchange)
			{
				x[k] = x[i];
				x[i] = data;
			}
	}
printf("The sorted array is ..............");
		for (i = 0; i <5;  i++)
		{
			printf ("\t%d", x[i]);
		}
}


