/*	This program demonstrates sizeof operator.
	written by :
	Date :
*/
#include<stdio.h>
main()
{
int i;
char c;
printf("integer 		%d\n ", 	sizeof i);
printf("character 	%d\n ", 	sizeof c);
printf("integer 		%d\n", 	sizeof (int));
printf("float 				%d\n", 	sizeof (float));
printf("double 			%d\n", 	sizeof (double));
}

