/*	This program demonstrates use of puts function.
	written by :
	Date :
*/
#include<stdio.h>
main()
{
	char s[40] = "Previously declared array of characters.";
	puts("Sequence of characters.");
	puts(s);
}