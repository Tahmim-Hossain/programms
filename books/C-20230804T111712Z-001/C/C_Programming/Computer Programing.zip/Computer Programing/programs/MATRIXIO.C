/* This program demonstrates how to initialize 2-D array and access it.
*/
#include<stdio.h>

void main()
	{
	int a[3][3];
	int i,j;
	clrscr(); 		 /* This function is used to clear the screen	*/
	printf("\nEnter the values of first matrix::\n");
	for(i=0;i<3;i++)
		{
		 for(j=0;j<3;j++)
			{
			printf("Matrix [%d][%d]: ",i,j);
			scanf("%d",&a[i][j]);
			}
		}

	 printf("\nMatrix is\n");
	 for(i=0;i<3;i++)
		{
		 for(j=0;j<3;j++)
			{
			printf("\t%d",a[i][j]);
			}
		printf("\n");
		}
}
