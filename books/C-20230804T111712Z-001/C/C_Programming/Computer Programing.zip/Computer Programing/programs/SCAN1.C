/*	This program demonstrates use of scanf function.
	written by :
	Date :
*/
#include<stdio.h>
main()
{
	char 	name[10];
	int  		rollno;
	float		pr_marks;
	scanf("%s %d %f", name, &rollno, &pr_marks); 	/*no & sign for name */
}

