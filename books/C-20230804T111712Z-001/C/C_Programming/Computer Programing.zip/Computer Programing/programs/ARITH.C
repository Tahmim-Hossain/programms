/*	This program demonstrates binary expressions using interger arithmetic.
	written by :
	Date :
*/
#include<stdio.h>
main()
{
/* Local Definitions */
int a = 14;
int b = 5;

/*Statements*/

printf("%d + %d = %d\n", a ,b, a + b);
printf("%d - %d = %d\n", a ,b, a - b);
printf("%d * %d = %d\n", a ,b, a * b);
printf("%d / %d = %d\n", a ,b, a / b);
printf("%d %% %d = %d\n", a ,b, a % b);

}