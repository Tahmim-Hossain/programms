/*	This program demonstrates pre-increment and post increment.
	written by :
	Date :
*/
#include<stdio.h>
main()
{
/* Local Definitions */
int p,q ;


/*Statements*/

p = 10;
q = 20;

printf("Value of p %d\n", p);
printf("Value of p++ %d\n", p++);
printf("new value of p %d\n", p);

printf("Value of q %d\n", q);
printf("Value of ++q %d\n", ++q);
printf("new value of q %d\n", q);

}